package com.example.cafelap.admin.AdminPage;

import com.example.cafelap.Users;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface APRepository extends JpaRepository<Users, Long> {
    List<Users> findByUserType(int userType);
}
