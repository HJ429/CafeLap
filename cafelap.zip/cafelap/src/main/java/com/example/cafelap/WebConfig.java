package com.example.cafelap;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import org.springframework.web.filter.CorsFilter;

import java.util.List;

@Configuration
public class WebConfig {
    @Bean
    public CorsFilter corsFilter() {
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        CorsConfiguration config = new CorsConfiguration();

        config.setAllowCredentials(true); // 인증 정보 포함 허용
        config.setAllowedOriginPatterns(List.of("*")); // 모든 도메인 허용 (실제 운영에서는 특정 도메인 지정)
        config.setAllowedHeaders(List.of("Authorization", "Content-Type", "X-Requested-With")); // 필요한 헤더만 허용
        config.setAllowedMethods(List.of("GET", "POST", "PUT", "DELETE", "OPTIONS")); // HTTP 메서드 허용
        config.addExposedHeader("Authorization"); // 클라이언트가 인증 헤더를 받을 수 있도록 설정

        source.registerCorsConfiguration("/**", config); // 모든 엔드포인트에 적용
        return new CorsFilter(source);
    }
}
