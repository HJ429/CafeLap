package com.example.cafelap.admin.lognin;

import com.example.cafelap.Users;
import com.example.cafelap.admin.signup.SignupRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.HashMap;
import java.util.Map;


@Controller
@RequestMapping("/api")
@CrossOrigin(origins = "http://localhost:5173")
public class LoginController {

    @Autowired
    private LoginService loginService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest loginRequest) {
        String userid = loginRequest.getUserid();
        String password = loginRequest.getPassword();

        Users user = loginService.login(userid, password); // boolean → User 객체로 수정

        if (user != null) {
            Map<String, Object> response = new HashMap<>();
            response.put("message", "로그인 성공");
            response.put("userType", user.getUserType()); // userType: 0, 1, 3

            return ResponseEntity.ok(response);
        } else {
            return ResponseEntity.status(401).body("아이디 또는 비밀번호가 틀렸습니다.");
        }
    }
}
