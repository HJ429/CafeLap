package com.example.cafelap;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CafelapApplication {

	public static void main(String[] args) {
		SpringApplication.run(CafelapApplication.class, args);
	}

}
