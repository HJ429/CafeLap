package com.example.cafelap.admin.AdminPage;

import com.example.cafelap.Users;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class APController {

    private final APRepository apRepository;

    //  생성자 주입
    @Autowired
    public APController(APRepository apRepository) {
        this.apRepository = apRepository;
    }

    //  userType이 0인 회원 목록 반환
    @GetMapping()
    public List<Users> getUsersByType(@RequestParam int userType) {
        return apRepository.findByUserType(userType);
    }


}
