package com.example.cafelap.admin.signup;

import com.example.cafelap.CafeAddress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CafeAddressRep extends JpaRepository<CafeAddress, Long> {
}
