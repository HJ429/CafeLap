package com.example.cafelap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CafelapApplicationTests {

	@Test
	void contextLoads() {
	}

}
