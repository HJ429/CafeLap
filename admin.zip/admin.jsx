import React, { useState, useEffect }from "react";
import { useNavigate } from "react-router-dom";
import Sidebar from "./sidebar";


const Admin = () => {
  const navigate = useNavigate();

  const [isAuthorized, setIsAuthorized] = useState(null);

    // ✅ 관리자 인증 체크
    useEffect(() => {
      const token = localStorage.getItem("token");
      const userType = parseInt(localStorage.getItem("userType"));
    
      if (!token || userType !== 3) {
        alert("정상적인 접근경로가 아닙니다.");
        setIsAuthorized(false); // ❗ 비인가일 때 false로 설정
        navigate("/login");
      } else {
        console.log("✅ 관리자 권한 확인 완료");
        setIsAuthorized(true); // ✅ 인가되었을 때 true로 설정
      }
    }, [navigate]);

    if (isAuthorized === false) {
      return null; // 비인가일 때는 아무것도 안 보여줌
    }
    
    if (isAuthorized === null) {
      return (
        <div style={{
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          height: "100vh",
          fontSize: "1.5rem"
        }}>
          🔒 정상적인 접근경로가 아닙니다.<br/>
       경로를 확인하여 다시 접근하여 주시길 바랍니다.
        </div>
      );
    }

  return (
    <div className="admin-board">
     {/* 사이드바 */}
     <div className="sidebar-allbox">
      <Sidebar />
     </div>

      {/* 메인 컨텐츠 */}
      <div className="main-content">
        <h1 className="main-h1">카페연구소 관리자 대시보드</h1>
        <div className="dashboard-cards">
          <div className="card-card-1">
            <h3>전체 회원</h3>
            <p>1,250명</p>
          </div>
          <div className="card-card-2">
            <h3>신규 가입</h3>
            <p>25명</p>
          </div>
        </div>
            <h1 className="admin-h1">승인대기목록</h1>
        <table className="board-table">
          <thead>
            <tr className="tr-total-middle">
              <th>번호</th>
              <th>카페이름</th>
              <th>작성자</th>
              <th>등록일</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>
            {[10, 9, 8].map((num) => (
              <tr key={num} className="list-tr">
                <td>{num}</td>
                <td>게시판 제목 {num}</td>
                <td>관리자</td>
                <td>2024-03-{20 - (10 - num)}</td>
                <td>
                  <button>승인</button>
                  <button className="delete-btn">거절</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        <div className="pagination">
          <button className="prev-btn">이전</button>
          <span className="active">1</span>
          <span>2</span>
          <span>3</span>
          <button className="next-btn">이후</button>
        </div>
      </div>
    </div>
  );
};

export default Admin;
