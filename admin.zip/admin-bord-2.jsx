import React, { useState, useEffect } from "react";
import Sidebar from "./sidebar";



const AdminList = () => {
  const [activePage, setActivePage] = useState(1);

  const handlePageClick = (page) => {
    setActivePage(page);
  };

  const renderRows = () => {
    const data = [
      { id: 10, title: "admin", author: "실험용",  date : "2025-04-09"},
      { id: 10, title: "admin", author: "실험용",  date : "2025-04-09"},
      { id: 10, title: "admin", author: "실험용",  date : "2025-04-09"},
      { id: 10, title: "admin", author: "실험용",  date : "2025-04-09"},
      { id: 10, title: "admin", author: "실험용",  date : "2025-04-09"}
    ];

    return data.map((item) => (
      <tr key={item.id}>
        <td>{item.id}</td>
        <td>{item.title}</td>
        <td>{item.author}</td>
        <td>{item.date}</td>
        <td>
          <button >수정</button>{" "}
          <button className="delete-btn">탈퇴</button>
        </td>
      </tr>
    ));
  };

  return (
    <div className="admin-board">
        {/* 사이드바 */}
        <div className="sidebar-allbox">
      <Sidebar />
     </div>

      {/* 메인 컨텐츠 */}
      <div className="mainlist-bord2-content">
        <h1 className="adminbord2-h1">카페연구소 자주 묻는 질문 목록</h1>

        <table className="admin-listboard-table-2">
          <thead>
            <tr>
              <th>번호</th>
              <th>게시물 제목</th>
              <th>작성자</th>
              <th>작성일자</th>
              <th>비고</th>
            </tr>
          </thead>
          <tbody>{renderRows()}</tbody>
        </table>

        <div className="pagination-bord-2">
          <button className="prev-btn">이전</button>
          {[1, 2, 3].map((page) => (
            <span
              key={page}
              className={activePage === page ? "active" : ""}
              onClick={() => handlePageClick(page)}
            >
              {page}
            </span>
          ))}
          <button className="next-btn">이후</button>
        </div>
      </div>
    </div>
  );
};

export default AdminList;
